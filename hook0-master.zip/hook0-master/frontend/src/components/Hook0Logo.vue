<script setup lang="ts">
import Hook0Text from '@/components/Hook0Text.vue';
import Hook0Icon from '@/components/Hook0Icon.vue';
</script>

<template>
  <div>
    <Hook0Icon name="link"></Hook0Icon>
    <Hook0Text class="ml-1">Hook0</Hook0Text>
  </div>
</template>

<style scoped>
div {
  @apply text-white;
}
</style>
