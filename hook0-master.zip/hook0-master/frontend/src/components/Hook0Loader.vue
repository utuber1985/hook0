<script setup lang="ts">
import Hook0Icon from '@/components/Hook0Icon.vue';
</script>

<template>
  <div class="flex justify-center items-center">
    <Hook0Icon name="circle-notch" size="2x" spin></Hook0Icon>
  </div>
</template>
