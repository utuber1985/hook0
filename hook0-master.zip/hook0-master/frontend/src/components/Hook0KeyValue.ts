export type Hook0KeyValueKeyValuePair = {
  key: string;
  value: string;
};
