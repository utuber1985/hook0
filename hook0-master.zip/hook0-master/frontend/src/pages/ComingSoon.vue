<script setup lang="ts">
import Hook0Card from '@/components/Hook0Card.vue';
import Hook0CardHeader from '@/components/Hook0CardHeader.vue';
</script>

<template>
  <Hook0Card>
    <Hook0CardHeader>
      <template #header>Coming soon...</template>
      <template #subtitle
        >Hook0 API is complete and production ready but the UI is still a work in progress...
      </template>
    </Hook0CardHeader>
  </Hook0Card>
</template>
