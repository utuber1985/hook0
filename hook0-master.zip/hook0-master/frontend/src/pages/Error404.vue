<script setup lang="ts">
import Hook0Card from '@/components/Hook0Card.vue';
import Hook0CardHeader from '@/components/Hook0CardHeader.vue';
</script>

<template>
  <Hook0Card>
    <Hook0CardHeader>
      <template #header>404 Not Found</template>
      <template #subtitle>Oops! </template>
    </Hook0CardHeader>
  </Hook0Card>
</template>
