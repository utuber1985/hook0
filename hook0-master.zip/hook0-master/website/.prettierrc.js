module.exports = {
  useTabs: false,
  printWidth: 220,
  tabWidth: 2,
  singleQuote: true,
  trailingComma: 'es5',
  jsxBracketSameLine: false,
  semi: true,
  parser: 'babel',
};
