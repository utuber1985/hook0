module.exports = {
  locals: require('./data'),
};
