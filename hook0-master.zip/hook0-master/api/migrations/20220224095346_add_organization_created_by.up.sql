alter table event.organization add column created_by uuid not null default '00000000-0000-0000-0000-000000000000';
