drop schema webhook cascade;
drop schema event cascade;
drop extension pgcrypto;
