drop materialized view event.events_per_day;
