alter table iam.user alter column email set data type text;

drop collation case_insensitive;
