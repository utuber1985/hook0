alter table event.organization drop column created_by;
