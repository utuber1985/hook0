drop table event.all_time_events_per_day;
