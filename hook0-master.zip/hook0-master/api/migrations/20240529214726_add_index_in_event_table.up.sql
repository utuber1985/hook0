create index if not exists event_application__id_idx on event.event (application__id);
