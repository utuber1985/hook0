drop index event.event_application__id_idx;
