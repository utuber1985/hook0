# Hook0 Self-Hosting Guide on Kubernetes

Read how to [setup Hook0 on Kubernetes here](https://documentation.hook0.com/docs/kubernetes).
